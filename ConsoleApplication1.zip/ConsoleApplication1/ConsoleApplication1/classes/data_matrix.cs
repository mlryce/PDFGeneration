﻿using PdfSharp.Drawing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1.classes
{
    public class data_matrix
    {
        //XImage data_matrix;

        //public void Draw_DM(XGraphics gfx, string DM_path, int x, int y, int width, int height){
                
        //       data_matrix = XImage.FromFile(DM_path);
        //       gfx.DrawImage(data_matrix, x, y, width, height);
        //}



        }
    }

